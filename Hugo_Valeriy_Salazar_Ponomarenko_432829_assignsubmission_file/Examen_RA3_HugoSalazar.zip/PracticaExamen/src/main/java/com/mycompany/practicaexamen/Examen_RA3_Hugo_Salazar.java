package com.mycompany.practicaexamen;

import java.util.Scanner;

public class Examen_RA3_Hugo_Salazar {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //escribe aqui tu codigo
        int opcion;
        
        boolean[][] clase = new boolean[3][12];
        String[] nombre = {"Yoga", "Spinning", "Boxeo"};
        
        for (int deporte = 0; deporte < 3; deporte++) {
            for (int plaza = 0; plaza < 12; plaza++) {
                clase[deporte][plaza] = false;
            }   
        }
        do{
            System.out.println("1. RESERVAR UNA PLAZA");
            System.out.println("2. CANCELAR UNA RESERVA");
            System.out.println("3. MOSTRAR TODAS LAS PLAZAS POR TIPO DE CLASE");
            System.out.println("4. PORCENTAJE RESERVADO POR CLASE");
            System.out.println("5. SALIR DEL MENU");
            System.out.println("ESCOGE LA OPCIO:");
            opcion = scanner.nextInt();
            
            switch (opcion){
                case 1:{
                    System.out.println("1. RESERVAR UNA PLAZA");
                    int deporte;
                        boolean reserva = false;
                        do{
                           System.out.println("Clase (1-3): 1.Yoga 2.Spinning 3.Boxeo");
                           deporte = scanner.nextInt();
                        } while (deporte < 1 || deporte > 3);
                        
                        for (int plaza = 0; plaza < 12; plaza++) {
                            if (clase[deporte - 1][plaza] == false){
                                clase[deporte - 1][plaza] = true;
                            System.out.println("Reserva confirmada clase " + nombre[deporte - 1] + ", plaza " + (plaza + 1));
                            reserva = true;
                            break;}
                    }        
                
                if (reserva == false) {
                    System.out.println("No hay plazas disponibles para " + nombre[deporte - 1]);
                }
                }
                break;
                
                case 2:{
                    System.out.println("1. CANCELAR UNA RESERVA");
                    int deporte;
                    int plaza;
                    do{
                           System.out.println("Clase (1-3): 1.Yoga 2.Spinning 3.Boxeo");
                           deporte = scanner.nextInt();
                        } while (deporte < 1 || deporte > 3);
                    
                    do{
                        System.out.println("Plaza (1-12)");
                        plaza = scanner.nextInt();
                    } while (plaza < 1 || plaza > 12);
                    
                    if (clase[deporte - 1][plaza - 1] == true){
                        clase[deporte - 1][plaza - 1] = false;
                        System.out.println("Reserva clase " + nombre[deporte - 1] + " plaza " + plaza + " anulada");
                    } else {
                        System.out.println("Reserva no encontrada");
                    }
                }break;
                
                case 3:{
                    System.out.println("1. MOSTRAR TODAS LAS PLAZAS POR TIPO DE CLASE");
                    for(int deporte = 0; deporte < 3; deporte++){
                        System.out.print(nombre[deporte] + ": ");
                        for (int plaza = 0; plaza < 12; plaza++) {
                            if (clase[deporte][plaza] == true){
                                System.out.print("Reservada");
                            } else{
                                System.out.print("Libre");
                                }
                            if (plaza < 11) {
                                System.out.print(", ");
                            }
                        }
                        System.out.println();
                    }
                }break;
                case 4: System.out.println("1. PORCENTAJE RESERVADO POR CLASE");break;
                case 5: System.out.println("1. SALIR DEL MENU");break;
                
            }
        }while(opcion != 5);
    }
}
